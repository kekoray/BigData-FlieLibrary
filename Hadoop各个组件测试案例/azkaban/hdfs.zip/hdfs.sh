#!/usr/bin/env bash

/usr/local/service/hadoop/bin/hadoop fs -mkdir /user/hadoop/azkaban_test/tmp
echo "======================  hdfs mkdir over ...   ============================= "