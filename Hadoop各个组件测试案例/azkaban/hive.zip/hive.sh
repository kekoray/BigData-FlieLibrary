#!/usr/bin/env bash

HIVE_PATH=/usr/local/service/hive/bin/hive
HADOOP_PATH=/usr/local/service/hadoop/bin/hadoop


#----------------切换用户----------------#

if [ `whoami` = "hadoop" ];then
 echo "hadoop用户"
 target_user=''
else
 echo "非hadoop用户！"
 target_user="sudo -u hadoop"
fi
#---------------------------------------#




hql_ExportToMySQLByHQL="use lazada_base;
set io.sort.mb=10; 
set hive.map.aggr=true； 
set hive.groupby.skewindata=false;
    insert overwrite local directory '/home/hadoop/test/20201110'
        row format delimited
    fields terminated by '\t'
    SELECT * FROM lazada_base.sqoop_test;"


${target_user} ${HIVE_PATH} -e "${hql_ExportToMySQLByHQL}"  