#!/usr/bin/env bash

mkdir /root/azkaban_test 
echo " mkdir over ... "